<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|


Route::get('/',function(){
    return view('welcome');
});*/

//Front Routes are listed below
Route::get('/','IndexController@index');

/*  Admin routes are listed below    */
;
Auth::routes();

//category listing page/Home page
Route::get('/products/{url}','ProductsController@products');

//Category detail page
Route::get('product/{id}','ProductsController@product');

//Get product attribute price
Route::get('/get-product-price','ProductsController@getProductPrice');

/*  Admin routes are listed below    */

Route::group(['prefix'=>'admin1'],function(){
    Route::match(['get','post'],'/','AdminController@login');
    Route::get('register','AdminController@register');
    Route::post('newuser','AdminController@store');
    Route::get('dashboard', 'AdminController@dashboard')->middleware('admin');
    Route::group(['middleware'=>'auth'],function() {

        Route::get('changepassword', 'HomeController@showChangePasswordForm');
        Route::post('change', 'HomeController@changePassword');
        /* Routes for user option */
        Route::get('userslist','UserController@index');
        Route::resource('users','UserController');

        //Category routes
        Route::match(['get','post'],'add-category','CategoryController@addCategory');
        Route::match(['get','post'],'edit-category/{id}','CategoryController@editCategory');
        Route::match(['get','post'],'delete-category/{id}','CategoryController@deleteCategory');
        Route::get('categorieslist','CategoryController@showCategories');

        //Product routes
        Route::match(['get','post'],'add_product','ProductsController@addProduct');
        Route::get('productslist','ProductsController@showProducts');
        Route::match(['get','post'],'edit-product/{id}','ProductsController@editProduct');
        Route::get('delete-product/{id}','ProductsController@deleteProduct');
        Route::get('delete-product-image/{id}','ProductsController@deleteProductImage');
        Route::get('delete-alt-image/{id}','ProductsController@deleteAltImage');


        //Products Attribute routes
        Route::match(['get','post'],'add-attribute/{id}','ProductsController@addAttributes');
        Route::get('delete-attribute/{id}','ProductsController@deleteAttributes');

        //Alternate product images
        Route::match(['get','post'],'add-images/{id}','ProductsController@addImages');
    });
});
//Route::get('/admin1','AdminController@login');


Route::group(['prefix'=>'user'] ,function(){
    Route::get('/',function(){
        return view('welcome');
    });
    Route::group(['middleware'=>'auth'],function() {
        Route::get('/home','HomeController@index');
    });

});

Route::get('/logout','AdminController@logout');


