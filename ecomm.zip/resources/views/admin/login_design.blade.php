
<!DOCTYPE html>
<html>
<head>

</head>
<body class="hold-transition login-page">
@include('admin.login_header');
@yield('content')
@include('admin.login_footer');

</body>
</html>