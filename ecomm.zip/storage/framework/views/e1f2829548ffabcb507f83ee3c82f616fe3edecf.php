
<!DOCTYPE html>
<html>
<head>

</head>
<body class="hold-transition login-page">
<?php echo $__env->make('admin.login_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('admin.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

</body>
</html><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/admin/login_design.blade.php ENDPATH**/ ?>