<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <form method="post" action = "<?php echo e(url('admin1/users',$users->id)); ?>">
                <input type="hidden" name="_method" value="PUT">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control"name="name" placeholder="" value="<?php echo e($users->name); ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" name ="email" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->email); ?>">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" name="admin" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Admin</label>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </section>
    </div>

<!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/users/user_edit.blade.php ENDPATH**/ ?>