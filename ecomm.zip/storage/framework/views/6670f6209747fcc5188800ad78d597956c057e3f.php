<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
        <div class="pull-left image">
            <img src="/admin/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
            <p>Alexander Pierce</p>
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
    </div>
    <!-- search form
    <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
            <input type="text" name="q" class="form-control" placeholder="Search...">
            <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
    </form>
    /.search form -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview menu-open">
            <a href="<?php echo e(url('admin1/dashboard')); ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
        </li>
<!-- Users Option -->
        <li class="active treeview menu-open">
            <a href="#">
                <i class="fa fa-dashboard"></i> <span>Users</span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
                <li class="active"><a href="<?php echo e(url('admin1/userslist')); ?>"><i class="fa fa-circle-o"></i> Users list</a></li>
                <li class="active"><a href="<?php echo e(url('admin1/users/create')); ?>"><i class="fa fa-circle-o"></i> Add new user</a></li>
            </ul>
        </li>

<!-- Categories options -->
        <li class="active treeview menu-open">
            <a href="#" id="categories_sidebar">
                <i class="fa fa-dashboard"></i> <span>Categories</span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul id="categories_list" class="treeview-menu">
                <li class="active"><a href="<?php echo e(url('admin1/categorieslist')); ?>"><i class="fa fa-circle-o"></i> Categories list</a></li>
                <li class="active"><a href="<?php echo e(url('admin1/add-category')); ?>"><i class="fa fa-circle-o"></i> Add new category</a></li>
            </ul>
        </li>

        <!-- Products options -->
        <li class="active treeview menu-open">
            <a href="#" id="categories_sidebar">
                <i class="fa fa-dashboard"></i> <span>Products</span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul id="products_list" class="treeview-menu">
                <li class="active"><a href="<?php echo e(url('admin1/productslist')); ?>"><i class="fa fa-circle-o"></i> Products list</a></li>
                <li class="active"><a href="<?php echo e(url('admin1/add_product')); ?>"><i class="fa fa-circle-o"></i> Add new product</a></li>
            </ul>
        </li>



    </ul>
</section>
<!-- /.sidebar --><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/layouts/admin_layout/admin_sidebar.blade.php ENDPATH**/ ?>