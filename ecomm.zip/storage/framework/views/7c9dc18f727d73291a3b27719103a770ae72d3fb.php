<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <?php if(Session::has('error')): ?>

            <div class="alert alert-error alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo session('error'); ?></strong>
            </div>
    <?php endif; ?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="box-header">
                <h3 class="box-title">ADD NEW USER</h3>
            </div>
            <br><br>
            <form method="post" action = "<?php echo e(url('admin1/users')); ?>" >
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control"name="name" placeholder="Enter name">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" name ="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Retype Password</label>
                    <input type="password" class="form-control" name="r_password" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" name="admin" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Admin</label>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </section>
    </div>

    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/users/user_add.blade.php ENDPATH**/ ?>