<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Categories
                <small></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="#">Categories</a></li>
                <li class="active">Categories list</li>
            </ol>
        </section>

        <!-- Main content -->
        <br>
        <?php if(Session::has('update_message')): ?>

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo session('update_message'); ?></strong>
            </div>
        <?php endif; ?>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Categories</h3>
                        </div>
                        <div>
                            <a href="<?php echo e(url('admin1/add-category')); ?>" class="btn btn-success" style="float:right; margin:10px;"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add new Category</a>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="category_table" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Category Name</th>
                                    <th>Category Level</th>
                                    <th>Description</th>
                                    <th>Url</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->parent_id); ?></td>
                                        <td><?php echo e($category->description); ?> </td>
                                        <td><?php echo e($category->url); ?> </td>
                                        <td>
                                            <a href="<?php echo e(url('/admin1/edit-category/'.$category->id)); ?>" class="btn btn-primary">Edit</a>
                                            <a href="<?php echo e(url('/admin1/delete-category/'.$category->id)); ?>" id="delCat" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/admin/categories/categories_list.blade.php ENDPATH**/ ?>