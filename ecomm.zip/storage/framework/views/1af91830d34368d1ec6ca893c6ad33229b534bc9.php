<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <?php if(Session::has('error')): ?>

            <div class="alert alert-error alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo session('error'); ?></strong>
            </div>
    <?php endif; ?>
    <!-- Content Header (Page header) -->
        <section class="content-header">
            <section class="content-header">
                <h1>
                    Edit categories
                    <small></small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li><a href="#">Categories</a></li>
                    <li class="active">Edit category</li>
                </ol>
            </section>
            <br><br>

            <!-- Category form -->
            <form  name="add_category" id="edit_category" method="post" action = "<?php echo e(url('/admin1/edit-category/'.$categoryDetails->id)); ?>"  >
            <?php echo e(csrf_field()); ?>

            <!--category name -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Category Name</label>
                    <input type="text" class="form-control"name="category_name" id="category_name" value="<?php echo e($categoryDetails->name); ?>">
                </div>

                <!--main-categories -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Category Level</label>
                    <select class="form-control" name="parent_id">
                        <option value="0">Main Category</option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->id); ?>" <?php if($val->id == $categoryDetails->parent_id): ?>
                                selected <?php endif; ?>><?php echo e($val->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!--category description -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Description </label>
                    <textarea class="form-control" name="description" id="description"><?php echo e($categoryDetails->description); ?></textarea>
                </div>

                <!--category url -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Url </label>
                    <input type="text" class="form-control"name="url" id="url" value="<?php echo e($categoryDetails->url); ?>">
                </div>

                <!--category enable/disable -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Enable </label>
                    <input type="checkbox" class=""name="status" id="status" <?php if($categoryDetails->status == '1'): ?> checked <?php endif; ?> value="1">
                </div>

                <a href="<?php echo e(url()->previous()); ?>"  class="btn btn-primary"><i class="fa fa-backward"></i> &nbsp;&nbsp;Back</a>
                <button type="submit" class="btn btn-primary" style="float: right">Edit Category</button>
            </form>


        </section>
    </div>

    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/admin/categories/edit_category.blade.php ENDPATH**/ ?>