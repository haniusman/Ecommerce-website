<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Products
                <small></small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="#">Products</a></li>
                <li class="active">Products list</li>
            </ol>
        </section>

        <!-- Main content -->
        <br>
        <?php if(Session::has('update_message')): ?>

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo session('update_message'); ?></strong>
            </div>
        <?php endif; ?>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title" id="prd" >Products</h3>
                        </div>
                        <div>
                            <a href="<?php echo e(url('admin1/add_product')); ?>" class="btn btn-success" style="float:right; margin:10px;"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add new Product</a>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="table" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Product ID</th>
                                    <th>Category Name</th>
                                    <th>Product Name</th>
                                    <th>Product code</th>
                                    <th>Product color</th>
                                    <th>Price</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->category_name); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->product_code); ?></td>
                                        <td><?php echo e($product->product_color); ?></td>
                                        <td><?php echo e($product->price); ?></td>
                                        <td>
                                            <?php if(!empty($product->image)): ?>
                                        <img src="<?php echo e(asset('/images/products/small/'.$product->image)); ?>" style="width:70px;">
                                        <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="#myModal<?php echo e($product->id); ?>" data-toggle="modal" title="View Product" class="btn btn-success">View</a>
                                            <a href="<?php echo e(url('/admin1/add-attribute/'.$product->id)); ?>" data-toggle="modal" id="add_attribute" title="Add Attributes" class="btn btn-warning">Add</a>
                                            <a href="<?php echo e(url('/admin1/add-images/'.$product->id)); ?>" data-toggle="modal" id="add_attribute" title="Add Images" class="btn btn-info">Add</a>
                                            <a href="<?php echo e(url('/admin1/edit-product/'.$product->id)); ?>" title="Edit Product" class="btn btn-primary">Edit</a>
                                            <a href="<?php echo e(url('/admin1/delete-product/'.$product->id)); ?>" id="delProduct" title="Delete Product" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>


                                    <!--popup -->
                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal<?php echo e($product->id); ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"><?php echo e($product->product_name); ?>  Full Details</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Product ID : <?php echo e($product->id); ?></p>
                                                    <p>Category ID : <?php echo e($product->category_id); ?></p>
                                                    <p>Category Name : <?php echo e($product->category_name); ?></p>
                                                    <p>Product Name : <?php echo e($product->product_name); ?></p>
                                                    <p>Product Code : <?php echo e($product->product_code); ?></p>
                                                    <p>Product Color : <?php echo e($product->product_color); ?></p>
                                                    <p>Price : <?php echo e($product->price); ?></p>
                                                    <p>Description : <?php echo e($product->description); ?></p>
                                                    <p>Care : <?php echo e($product->care); ?></p>

                                                <?php if(!empty($product->image)): ?>
                                                        <img src="<?php echo e(asset('/images/products/medium/'.$product->image)); ?>" style="width:250px; ">
                                                    <?php endif; ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
<script>
    $("#delProduct").click(function(){
        if(confirm('Are you sure you want to delete the product?'))
        {
          return true;
        }
        return false;
    });

</script>

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/admin/products/products_list.blade.php ENDPATH**/ ?>