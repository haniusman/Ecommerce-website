<?php $__env->startSection('content'); ?>
<h1 style="background-color: #00cc66; color: black; ">Settings</h1>
<form method="post" action="<?php echo e(url('admin1/settings/changePassword')); ?>">
    <button type="button" class="btn btn-success">Change Password</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\resources\views/admin/settings.blade.php ENDPATH**/ ?>