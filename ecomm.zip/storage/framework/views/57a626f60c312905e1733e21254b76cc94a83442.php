<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="logo-404">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/frontend_images/home/logo.png')); ?>" alt="" /></a>
        </div>
        <div class="content-404">
            <h1><b>OPPS!</b> We Couldn’t Find this Page</h1>
            <p>Uh... So it looks like you brock something. The page you are looking for has up and Vanished.</p>
            <h2><a href="<?php echo e(url('/')); ?>">Bring me back Home</a></h2>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_layout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umehani\laragon\www\ecomm\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>